package com.billienoughfakepixel.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class BefConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir().resolve("billienoughfakepixel.json");

    public static BefConfig INSTANCE = new BefConfig();

    // ==================== MOBILE & RENDERER OPTIMIZATION ====================
    // Designed for Poco X6 Pro (Mali-G615), Low-End Devices, MobileGlues & GL4ES
    public boolean mobileGluesGl4esSafeMode = true;
    public boolean lowEndMobileFastMode = false;

    // ==================== QUALITY OF LIFE ====================
    public boolean disableBlockBreakingParticles = true;
    public boolean alwaysSprint = true;
    public boolean copyChatMessage = true;
    public boolean fullBlockLever = true;
    public boolean blockPlacingItems = true;
    public boolean etherwarpOverlay = true;
    public boolean etherwarpSounds = true;
    public boolean etherwarpZoom = true;
    public float etherwarpZoomFov = 35.0f;
    public boolean hideFlamingFists = true;
    public boolean hidePlayerArmor = false;
    public boolean hideDeadMobs = true;
    public boolean hideFallingBlocks = true;
    public boolean itemAnimations = true;
    public float itemScale = 0.85f;
    public boolean smolPeople = false;
    public float smolPeopleScale = 0.65f;
    public boolean reforgeHelper = true;
    public boolean disableHyperionExplosions = true;
    public boolean disableThunderlordBolts = true;
    public boolean noHurtCamera = true;
    public boolean fullbright = true;
    public boolean disablePotionEffectsInInventory = true;
    public boolean equipmentOverlay = true;
    public boolean middleClickMenus = true;
    public boolean disableJerryAoteSounds = true;
    public boolean midasStaffMinimal = true;
    public boolean wardrobeKeyShortcut = true;
    public boolean equipmentKeyShortcut = true;
    public boolean hidePlayersCloseToNpcs = true;
    public boolean missingAccessoriesGui = true;
    public boolean showEnderNodes = true;
    public boolean disableInfoWatchdogMessages = true;

    // ==================== DUNGEONS: GENERAL ====================
    public boolean customLeapGui = true;
    public boolean leapGuiClassColors = true;
    public int archerColor = 0xFFFF5555;   // Red
    public int berserkColor = 0xFFFFAA00;  // Gold/Orange
    public int mageColor = 0xFF55FFFF;     // Aqua
    public int healerColor = 0xFFFF55FF;   // Pink
    public int tankColor = 0xFF55FF55;     // Green

    public boolean customTerminalGui = true;
    public boolean bloodReadyTitle = true;
    public boolean boulderSolver = true;
    public boolean silverfishSolver = true;
    public boolean witherDoorsHighlight = true;
    public boolean teleportMazeSolver = true;
    public boolean terminalWaypoints = true;
    public boolean customSPlusMessage = true;
    public String sPlusMessageText = "S+ Reached! Ready for boss!";
    public boolean spiritBowTracer = true;
    public boolean dungeonMap = true;
    public boolean threeWeirdosSolver = true;
    public boolean autoReady = false;
    public boolean autoCloseSecretChests = true;
    public boolean hideUnableToLocateSign = true;
    public boolean sPlusReminder = true;
    public boolean scoreOverlay = true;
    public boolean secretOverlay = true;
    public boolean preventSalvagingEpic = true;
    public boolean preventSalvagingLegendary = true;
    public boolean preventSalvagingMythic = true;

    // ==================== DUNGEONS: STARRED MOBS ====================
    public boolean starredMobDisplay = true;
    public boolean felPositionDisplay = true;
    public boolean batPositionDisplay = true;

    // ==================== FLOOR 7 & MASTER MODE 7 ====================
    public boolean terminalSolvers = true;
    public boolean terminalTracker = true;
    public boolean boxWithers = true;
    public boolean m7DragonHighlight = true;
    public boolean m7RelicWaypoints = true;

    // ==================== EXPERIMENTATION TABLE ====================
    public boolean chronomatronSolver = true;
    public boolean ultrasequencerSolver = true;
    public boolean preventExperimentMissclicks = true;
    public boolean superpairsSolver = true;

    // ==================== SLAYERS ====================
    public boolean voidgloomBeaconWaypoint = true;
    public boolean minibossSpawnAlert = true;
    public boolean slayerHealthDisplay = true;
    public boolean slayerBossTime = true;
    public boolean blazePillarTitle = true;
    public boolean blazeAttunements = true;

    public static void load() {
        if (Files.exists(CONFIG_PATH)) {
            try {
                String json = Files.readString(CONFIG_PATH);
                BefConfig loaded = GSON.fromJson(json, BefConfig.class);
                if (loaded != null) {
                    INSTANCE = loaded;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            save();
        }
    }

    public static void save() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            Files.writeString(CONFIG_PATH, GSON.toJson(INSTANCE));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
