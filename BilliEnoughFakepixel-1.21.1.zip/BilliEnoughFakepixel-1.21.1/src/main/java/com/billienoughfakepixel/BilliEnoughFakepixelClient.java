package com.billienoughfakepixel;

import com.billienoughfakepixel.config.BefConfig;
import com.billienoughfakepixel.features.dungeons.DungeonManager;
import com.billienoughfakepixel.features.dungeons.Floor7Manager;
import com.billienoughfakepixel.features.dungeons.Master7Manager;
import com.billienoughfakepixel.features.dungeons.PuzzleSolvers;
import com.billienoughfakepixel.features.experimentation.ExperimentationSolver;
import com.billienoughfakepixel.features.qol.QolManager;
import com.billienoughfakepixel.features.slayers.SlayerManager;
import com.billienoughfakepixel.gui.BefConfigScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BilliEnoughFakepixelClient implements ClientModInitializer {
    public static final String MOD_ID = "billienoughfakepixel";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static KeyBinding openConfigKey;
    public static KeyBinding wardrobeKey;
    public static KeyBinding equipmentKey;
    public static KeyBinding etherwarpZoomKey;

    @Override
    public void onInitializeClient() {
        BefConfig.load();

        openConfigKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.billienoughfakepixel.config", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.billienoughfakepixel"
        ));
        wardrobeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.billienoughfakepixel.wardrobe", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, "category.billienoughfakepixel"
        ));
        equipmentKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.billienoughfakepixel.equipment", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, "category.billienoughfakepixel"
        ));
        etherwarpZoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.billienoughfakepixel.etherwarp_zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Z, "category.billienoughfakepixel"
        ));

        // Register /bef command (and /billienoughfakepixel alias)
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("bef").executes(ctx -> {
                MinecraftClient client = MinecraftClient.getInstance();
                client.send(() -> client.setScreen(new BefConfigScreen(client.currentScreen)));
                return 1;
            }));
            dispatcher.register(ClientCommandManager.literal("billienoughfakepixel").executes(ctx -> {
                MinecraftClient client = MinecraftClient.getInstance();
                client.send(() -> client.setScreen(new BefConfigScreen(client.currentScreen)));
                return 1;
            }));
        });

        // Client tick events
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openConfigKey.wasPressed()) {
                client.setScreen(new BefConfigScreen(client.currentScreen));
            }
            QolManager.onTick(client);
            DungeonManager.onTick(client);
            PuzzleSolvers.onTick(client);
            Floor7Manager.onTick(client);
            Master7Manager.onTick(client);
            SlayerManager.onTick(client);
            ExperimentationSolver.onTick(client);
        });

        // World render events
        WorldRenderEvents.AFTER_TRANSLUCENT.register(context -> {
            QolManager.onWorldRender(context);
            DungeonManager.onWorldRender(context);
            PuzzleSolvers.onWorldRender(context);
            Floor7Manager.onWorldRender(context);
            Master7Manager.onWorldRender(context);
            SlayerManager.onWorldRender(context);
        });

        // HUD render events
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            QolManager.onHudRender(drawContext);
            DungeonManager.onHudRender(drawContext);
            Floor7Manager.onHudRender(drawContext);
            SlayerManager.onHudRender(drawContext);
        });

        // Chat message events
        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> {
            String raw = message.getString();
            if (!QolManager.onChatMessage(raw)) return false;
            if (!DungeonManager.onChatMessage(raw)) return false;
            PuzzleSolvers.onChatMessage(raw);
            Floor7Manager.onChatMessage(raw);
            SlayerManager.onChatMessage(raw);
            return true;
        });

        LOGGER.info("BilliEnoughFakepixel (BEF) Fabric 1.21.1 initialized!");
    }
}
