package com.billienoughfakepixel.features.dungeons;

import com.billienoughfakepixel.config.BefConfig;
import com.billienoughfakepixel.utils.RenderUtils;
import com.billienoughfakepixel.utils.ScoreboardUtils;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.SilverfishEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class PuzzleSolvers {
    private static final List<String> WEIRDOS_ANSWERS = List.of(
            "The reward is not in my chest!",
            "At least one of them is lying, and the reward is not in",
            "My chest doesn't have the reward. We are all telling the truth.",
            "My chest has the reward and I'm telling the truth",
            "The reward isn't in any of our chests.",
            "Both of them are telling the truth."
    );

    private static BlockPos weirdosChest = null;
    private static final Set<BlockPos> visitedTeleportPads = new HashSet<>();
    private static final List<BlockPos> nearbyTeleportPads = new ArrayList<>();
    private static final List<BlockPos> boulderTargets = new ArrayList<>();
    private static Vec3d silverfishPos = null;
    private static int tickCounter = 0;

    public static void onTick(MinecraftClient client) {
        if (client.world == null || client.player == null || !ScoreboardUtils.isInDungeons()) {
            weirdosChest = null;
            visitedTeleportPads.clear();
            nearbyTeleportPads.clear();
            boulderTargets.clear();
            silverfishPos = null;
            return;
        }

        BefConfig cfg = BefConfig.INSTANCE;
        tickCounter++;
        int scanRate = cfg.lowEndMobileFastMode ? 25 : 15;

        // Teleport Maze pad tracking
        if (cfg.teleportMazeSolver) {
            BlockPos below = client.player.getBlockPos().down();
            if (client.world.getBlockState(below).isOf(Blocks.END_PORTAL_FRAME)) {
                visitedTeleportPads.add(below.toImmutable());
            }
            if (tickCounter % scanRate == 0) {
                nearbyTeleportPads.clear();
                for (BlockPos pos : BlockPos.iterateOutwards(client.player.getBlockPos(), 16, 3, 16)) {
                    if (client.world.getBlockState(pos).isOf(Blocks.END_PORTAL_FRAME)) {
                        nearbyTeleportPads.add(pos.toImmutable());
                    }
                }
            }
        }

        // Boulder Solver scan
        if (cfg.boulderSolver && tickCounter % scanRate == 0) {
            boulderTargets.clear();
            for (BlockPos pos : BlockPos.iterateOutwards(client.player.getBlockPos(), 16, 5, 16)) {
                if (client.world.getBlockState(pos).isOf(Blocks.CHEST)
                        && client.world.getBlockState(pos.down()).isOf(Blocks.OAK_PLANKS)) {
                    boulderTargets.add(pos.toImmutable());
                }
            }
        }

        // Silverfish Solver entity tracking
        if (cfg.silverfishSolver && tickCounter % 2 == 0) {
            silverfishPos = null;
            for (Entity e : client.world.getEntities()) {
                if (e instanceof SilverfishEntity && e.squaredDistanceTo(client.player) < 28 * 28) {
                    silverfishPos = e.getPos();
                    break;
                }
            }
        }
    }

    public static void onWorldRender(WorldRenderContext context) {
        if (!ScoreboardUtils.isInDungeons()) return;
        BefConfig cfg = BefConfig.INSTANCE;

        // Three Weirdos Solver
        if (cfg.threeWeirdosSolver && weirdosChest != null) {
            RenderUtils.drawFilledBox(context, new Box(weirdosChest), 0x6000FF00, true);
            RenderUtils.drawBlockOutline(context, weirdosChest, 0xFF00FF00, true);
            RenderUtils.drawWaypointLabel(context, Vec3d.ofCenter(weirdosChest).add(0, 1.0, 0), "§a§lCORRECT CHEST", 0xFF55FF55);
        }

        // Teleport Maze Solver
        if (cfg.teleportMazeSolver) {
            for (BlockPos pad : nearbyTeleportPads) {
                int color = visitedTeleportPads.contains(pad) ? 0xFFFF3333 : 0xFF00FF88;
                RenderUtils.drawBlockOutline(context, pad, color, true);
            }
        }

        // Boulder Solver
        if (cfg.boulderSolver) {
            for (BlockPos chest : boulderTargets) {
                RenderUtils.drawBlockOutline(context, chest, 0xFF00FFFF, true);
                RenderUtils.drawWaypointLabel(context, Vec3d.ofCenter(chest).add(0, 1.0, 0), "§bBoulder Chest", 0xFF55FFFF);
            }
        }

        // Silverfish Solver
        if (cfg.silverfishSolver && silverfishPos != null) {
            RenderUtils.drawBoxOutline(context, new Box(silverfishPos.x - 0.5, silverfishPos.y, silverfishPos.z - 0.5,
                    silverfishPos.x + 0.5, silverfishPos.y + 0.6, silverfishPos.z + 0.5), 0xFF00FF00, true);
            RenderUtils.drawWaypointLabel(context, silverfishPos.add(0, 1.0, 0), "§aSilverfish Target", 0xFF55FF55);
        }
    }

    public static void onChatMessage(String raw) {
        if (!BefConfig.INSTANCE.threeWeirdosSolver) return;
        String clean = ScoreboardUtils.stripColor(raw);
        if (!clean.startsWith("[NPC]")) return;

        for (String ans : WEIRDOS_ANSWERS) {
            if (clean.contains(ans)) {
                int colon = clean.indexOf(':');
                if (colon <= 6) continue;
                String npcName = clean.substring(6, colon).trim();
                MinecraftClient client = MinecraftClient.getInstance();
                if (client.world != null) {
                    for (Entity e : client.world.getEntities()) {
                        if (e instanceof ArmorStandEntity && ScoreboardUtils.stripColor(e.getName().getString()).contains(npcName)) {
                            BlockPos npcPos = e.getBlockPos();
                            for (BlockPos pos : BlockPos.iterateOutwards(npcPos, 4, 2, 4)) {
                                if (client.world.getBlockState(pos).isOf(Blocks.CHEST)) {
                                    weirdosChest = pos.toImmutable();
                                    return;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
