package com.billienoughfakepixel.features.qol;

import com.billienoughfakepixel.BilliEnoughFakepixelClient;
import com.billienoughfakepixel.config.BefConfig;
import com.billienoughfakepixel.utils.ItemUtils;
import com.billienoughfakepixel.utils.RenderUtils;
import com.billienoughfakepixel.utils.ScoreboardUtils;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

public class QolManager {
    private static boolean registeredCallbacks = false;
    private static BlockPos etherwarpTarget = null;
    private static final List<BlockPos> enderNodes = new ArrayList<>();
    private static int tickCounter = 0;

    public static void ensureCallbacks() {
        if (registeredCallbacks) return;
        registeredCallbacks = true;

        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (!world.isClient()) return ActionResult.PASS;
            if (!BefConfig.INSTANCE.blockPlacingItems) return ActionResult.PASS;
            ItemStack stack = player.getStackInHand(hand);
            if (ItemUtils.isTeleportOrAbilityItem(stack)) {
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });
    }

    public static void onTick(MinecraftClient client) {
        ensureCallbacks();
        if (client.player == null || client.world == null) return;

        BefConfig cfg = BefConfig.INSTANCE;

        // Always sprint
        if (cfg.alwaysSprint && client.options.forwardKey.isPressed() && !client.player.isSneaking()) {
            client.player.setSprinting(true);
        }

        // Wardrobe & Equipment shortcuts
        if (cfg.wardrobeKeyShortcut) {
            while (BilliEnoughFakepixelClient.wardrobeKey.wasPressed()) {
                if (client.getNetworkHandler() != null) {
                    client.getNetworkHandler().sendChatCommand("wardrobe");
                }
            }
        }
        if (cfg.equipmentKeyShortcut) {
            while (BilliEnoughFakepixelClient.equipmentKey.wasPressed()) {
                if (client.getNetworkHandler() != null) {
                    client.getNetworkHandler().sendChatCommand("equipment");
                }
            }
        }

        // Etherwarp raycast (when sneaking + holding AOTV/AOTE)
        etherwarpTarget = null;
        if (cfg.etherwarpOverlay && client.player.isSneaking()) {
            ItemStack main = client.player.getMainHandStack();
            if (isEtherwarpItem(main)) {
                HitResult hit = client.player.raycast(61.0, 0.0f, false);
                if (hit instanceof BlockHitResult bhr && hit.getType() == HitResult.Type.BLOCK) {
                    BlockPos pos = bhr.getBlockPos();
                    if (client.world.getBlockState(pos.up()).isAir() && client.world.getBlockState(pos.up(2)).isAir()) {
                        etherwarpTarget = pos;
                    }
                }
            }
        }

        // Lightweight entity-first Ender Node scan
        tickCounter++;
        int scanRate = cfg.lowEndMobileFastMode ? 30 : 20;
        if (cfg.showEnderNodes && tickCounter % scanRate == 0) {
            enderNodes.clear();
            for (Entity e : client.world.getEntities()) {
                if (e instanceof ArmorStandEntity && e.squaredDistanceTo(client.player) < 32 * 32) {
                    String n = ScoreboardUtils.stripColor(e.getName().getString()).toLowerCase();
                    if (n.contains("ender node")) {
                        enderNodes.add(e.getBlockPos().down().toImmutable());
                    }
                }
            }
        }
    }

    public static boolean isEtherwarpItem(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        for (String line : ItemUtils.getLoreLines(stack)) {
            if (line.toLowerCase().contains("ether transmission")) {
                return true;
            }
        }
        String name = ScoreboardUtils.stripColor(stack.getName().getString()).toLowerCase();
        return name.contains("aspect of the void");
    }

    public static void playEtherwarpSound() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null && BefConfig.INSTANCE.etherwarpSounds) {
            client.player.playSound(SoundEvents.ENTITY_ENDER_DRAGON_HURT, 0.5f, 1.8f);
        }
    }

    public static void onWorldRender(WorldRenderContext context) {
        BefConfig cfg = BefConfig.INSTANCE;
        if (cfg.etherwarpOverlay && etherwarpTarget != null) {
            RenderUtils.drawFilledBox(context, new Box(etherwarpTarget), 0x4555FFFF, true);
            RenderUtils.drawBlockOutline(context, etherwarpTarget, 0xFF00FFFF, true);
        }

        if (cfg.showEnderNodes) {
            for (BlockPos node : enderNodes) {
                RenderUtils.drawBlockOutline(context, node, 0xFFCC44FF, true);
                RenderUtils.drawWaypointLabel(context, Vec3d.ofCenter(node).add(0, 0.8, 0), "§dEnder Node", 0xFFFF55FF);
            }
        }
    }

    public static void onHudRender(DrawContext context) {
        BefConfig cfg = BefConfig.INSTANCE;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        if (cfg.equipmentOverlay && ScoreboardUtils.isInFakepixelSkyblock()) {
            int x = 8;
            int y = client.getWindow().getScaledHeight() - 62;
            context.fill(x - 2, y - 2, x + 98, y + 54, 0x8010141C);
            context.drawTextWithShadow(client.textRenderer, "§b§lEquipment", x + 2, y, 0xFFFFFFFF);
            context.drawTextWithShadow(client.textRenderer, "§7Necklace / Cloak", x + 2, y + 12, 0xFFCCCCCC);
            context.drawTextWithShadow(client.textRenderer, "§7Belt / Gloves", x + 2, y + 24, 0xFFCCCCCC);
            context.drawTextWithShadow(client.textRenderer, "§8[/equipment]", x + 2, y + 38, 0xFF888888);
        }
    }

    public static boolean onChatMessage(String raw) {
        String clean = ScoreboardUtils.stripColor(raw);
        if (BefConfig.INSTANCE.disableInfoWatchdogMessages) {
            if (clean.contains("[WATCHDOG ANNOUNCEMENT]")
                    || clean.contains("Watchdog has banned")
                    || clean.contains("Blacklisted modifications are a bannable offense")
                    || clean.startsWith("[INFO]")) {
                return false;
            }
        }
        return true;
    }
}
