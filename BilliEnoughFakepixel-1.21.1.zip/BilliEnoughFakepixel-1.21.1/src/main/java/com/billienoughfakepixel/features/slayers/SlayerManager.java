package com.billienoughfakepixel.features.slayers;

import com.billienoughfakepixel.config.BefConfig;
import com.billienoughfakepixel.utils.RenderUtils;
import com.billienoughfakepixel.utils.ScoreboardUtils;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

public class SlayerManager {
    private static final List<BlockPos> voidgloomBeacons = new ArrayList<>();
    private static String activeSlayerHp = "";
    private static String activeBlazeAttunement = "";
    private static long bossSpawnTimeMs = 0L;
    private static long lastBossKillTimeMs = 0L;
    private static int tickCounter = 0;

    public static void onTick(MinecraftClient client) {
        if (client.world == null || client.player == null) return;
        BefConfig cfg = BefConfig.INSTANCE;
        tickCounter++;

        // Scan Voidgloom beacons every 15 ticks (or 25 in Low-End Fast Mode)
        int beaconScanInterval = cfg.lowEndMobileFastMode ? 25 : 15;
        if (cfg.voidgloomBeaconWaypoint && tickCounter % beaconScanInterval == 0) {
            voidgloomBeacons.clear();
            BlockPos p = client.player.getBlockPos();
            int r = cfg.lowEndMobileFastMode ? 14 : 18;
            for (BlockPos pos : BlockPos.iterateOutwards(p, r, 6, r)) {
                if (client.world.getBlockState(pos).isOf(Blocks.BEACON)) {
                    voidgloomBeacons.add(pos.toImmutable());
                }
            }
        }

        // Scan Slayer boss armor stands every 4 ticks
        if (tickCounter % 4 == 0) {
            activeSlayerHp = "";
            activeBlazeAttunement = "";
            for (Entity e : client.world.getEntities()) {
                if (!(e instanceof ArmorStandEntity) || e.squaredDistanceTo(client.player) > 32 * 32) continue;
                String name = ScoreboardUtils.stripColor(e.getName().getString());
                if (name.contains("Voidgloom Seraph") || name.contains("Inferno Demonlord")
                        || name.contains("Revenant Horror") || name.contains("Tarantula Broodfather")
                        || name.contains("Sven Packmaster")) {
                    if (cfg.slayerHealthDisplay) {
                        activeSlayerHp = name;
                    }
                    if (bossSpawnTimeMs == 0L) {
                        bossSpawnTimeMs = System.currentTimeMillis();
                    }
                }

                if (cfg.blazeAttunements) {
                    if (name.contains("ASHEN")) activeBlazeAttunement = "§8§lASHEN (Stone/Coal)";
                    else if (name.contains("AURIC")) activeBlazeAttunement = "§e§lAURIC (Gold)";
                    else if (name.contains("CRYSTAL")) activeBlazeAttunement = "§b§lCRYSTAL (Diamond)";
                    else if (name.contains("SPIRIT")) activeBlazeAttunement = "§f§lSPIRIT (Iron)";
                }

                if (cfg.blazePillarTitle && name.contains("s") && name.matches(".*\\d+s.*") && e.squaredDistanceTo(client.player) < 25 * 25) {
                    client.inGameHud.setTitle(Text.literal("§c§lPILLAR: " + name));
                }
            }
        }
    }

    public static void onWorldRender(WorldRenderContext context) {
        if (BefConfig.INSTANCE.voidgloomBeaconWaypoint) {
            for (BlockPos beacon : voidgloomBeacons) {
                RenderUtils.drawFilledBox(context, new Box(beacon), 0x55FF00FF, true);
                RenderUtils.drawBlockOutline(context, beacon, 0xFFFF00FF, true);
                RenderUtils.drawTracer(context, Vec3d.ofCenter(beacon), 0xFFFF00FF);
                RenderUtils.drawWaypointLabel(context, Vec3d.ofCenter(beacon).add(0, 1.2, 0), "§d§lBEACON", 0xFFFF55FF);
            }
        }
    }

    public static void onHudRender(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        BefConfig cfg = BefConfig.INSTANCE;

        int y = 60;
        if (cfg.slayerHealthDisplay && !activeSlayerHp.isEmpty()) {
            context.drawTextWithShadow(client.textRenderer, "§c§lSlayer: §f" + activeSlayerHp, 10, y, 0xFFFFFFFF);
            y += 12;
        }
        if (cfg.slayerBossTime && bossSpawnTimeMs > 0) {
            double sec = (System.currentTimeMillis() - bossSpawnTimeMs) / 1000.0;
            context.drawTextWithShadow(client.textRenderer, String.format("§eBoss Time: §f%.1fs", sec), 10, y, 0xFFFFFFFF);
            y += 12;
        } else if (cfg.slayerBossTime && lastBossKillTimeMs > 0) {
            context.drawTextWithShadow(client.textRenderer, String.format("§aLast Boss: §f%.2fs", lastBossKillTimeMs / 1000.0), 10, y, 0xFFFFFFFF);
            y += 12;
        }
        if (cfg.blazeAttunements && !activeBlazeAttunement.isEmpty()) {
            context.drawTextWithShadow(client.textRenderer, "§6Attunement: " + activeBlazeAttunement, 10, y, 0xFFFFFFFF);
        }
    }

    public static void onChatMessage(String raw) {
        String clean = ScoreboardUtils.stripColor(raw);
        MinecraftClient client = MinecraftClient.getInstance();

        if (BefConfig.INSTANCE.minibossSpawnAlert && (clean.contains("SLAYER MINI-BOSS") || clean.contains("A miniboss has spawned"))) {
            if (client.player != null) {
                client.inGameHud.setTitle(Text.literal("§c§lMINIBOSS SPAWNED!"));
                client.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
            }
        }

        if (clean.contains("NICE! SLAYER BOSS SLAIN!") || clean.contains("SLAYER QUEST COMPLETE!")) {
            if (bossSpawnTimeMs > 0) {
                lastBossKillTimeMs = System.currentTimeMillis() - bossSpawnTimeMs;
                bossSpawnTimeMs = 0L;
            }
        }
    }
}
