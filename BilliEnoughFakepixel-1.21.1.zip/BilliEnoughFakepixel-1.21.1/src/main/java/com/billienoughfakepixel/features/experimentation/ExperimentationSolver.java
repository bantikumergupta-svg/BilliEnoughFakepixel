package com.billienoughfakepixel.features.experimentation;

import com.billienoughfakepixel.config.BefConfig;
import com.billienoughfakepixel.utils.ScoreboardUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.Slot;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExperimentationSolver {
    private static final List<Integer> chronomatronOrder = new ArrayList<>();
    private static int chronomatronStep = 0;

    private static final Map<Integer, Integer> ultrasequencerOrder = new HashMap<>();
    private static final Map<Integer, String> superpairsRevealed = new HashMap<>();

    public static void onTick(MinecraftClient client) {
        if (!(client.currentScreen instanceof HandledScreen<?> screen)) {
            chronomatronOrder.clear();
            chronomatronStep = 0;
            ultrasequencerOrder.clear();
            superpairsRevealed.clear();
            return;
        }
        String title = ScoreboardUtils.stripColor(screen.getTitle().getString());

        if (title.contains("Chronomatron") && BefConfig.INSTANCE.chronomatronSolver) {
            boolean rememberPhase = false;
            for (Slot slot : screen.getScreenHandler().slots) {
                if (slot.id == 49 && slot.getStack().isOf(Items.CLOCK)) {
                    rememberPhase = true;
                }
            }
            if (rememberPhase) {
                for (Slot slot : screen.getScreenHandler().slots) {
                    if (slot.id < 54 && slot.getStack().hasGlint()) {
                        if (chronomatronOrder.isEmpty() || chronomatronOrder.get(chronomatronOrder.size() - 1) != slot.id) {
                            chronomatronOrder.add(slot.id);
                        }
                    }
                }
                chronomatronStep = 0;
            }
        }

        if (title.contains("Ultrasequencer") && BefConfig.INSTANCE.ultrasequencerSolver) {
            ultrasequencerOrder.clear();
            for (Slot slot : screen.getScreenHandler().slots) {
                if (slot.id < 54) {
                    ItemStack st = slot.getStack();
                    if (!st.isEmpty() && st.getItem().toString().contains("dye")) {
                        ultrasequencerOrder.put(slot.id, st.getCount());
                    }
                }
            }
        }

        if (title.contains("Superpairs") && BefConfig.INSTANCE.superpairsSolver) {
            for (Slot slot : screen.getScreenHandler().slots) {
                if (slot.id < 54) {
                    ItemStack st = slot.getStack();
                    if (!st.isEmpty()
                            && !st.isOf(Items.BLACK_STAINED_GLASS_PANE)
                            && !st.isOf(Items.CYAN_STAINED_GLASS_PANE)
                            && !st.isOf(Items.GRAY_STAINED_GLASS_PANE)) {
                        String key = st.getItem().toString() + ":" + ScoreboardUtils.stripColor(st.getName().getString());
                        superpairsRevealed.put(slot.id, key);
                    }
                }
            }
        }
    }

    public static void renderSlotOverlay(DrawContext context, HandledScreen<?> screen, Slot slot) {
        String title = ScoreboardUtils.stripColor(screen.getTitle().getString());

        if (title.contains("Chronomatron") && BefConfig.INSTANCE.chronomatronSolver) {
            if (chronomatronStep < chronomatronOrder.size() && chronomatronOrder.get(chronomatronStep) == slot.id) {
                context.fill(slot.x, slot.y, slot.x + 16, slot.y + 16, 0x9900FF00);
            }
        }

        if (title.contains("Ultrasequencer") && BefConfig.INSTANCE.ultrasequencerSolver) {
            Integer order = ultrasequencerOrder.get(slot.id);
            if (order != null) {
                int minOrder = ultrasequencerOrder.values().stream().min(Comparator.naturalOrder()).orElse(1);
                int color = (order == minOrder) ? 0xAA00FF00 : 0x55FFFF00;
                context.fill(slot.x, slot.y, slot.x + 16, slot.y + 16, color);
                context.drawTextWithShadow(MinecraftClient.getInstance().textRenderer,
                        String.valueOf(order), slot.x + 4, slot.y + 4, 0xFFFFFFFF);
            }
        }

        if (title.contains("Superpairs") && BefConfig.INSTANCE.superpairsSolver) {
            String key = superpairsRevealed.get(slot.id);
            if (key != null) {
                long matches = superpairsRevealed.values().stream().filter(v -> v.equals(key)).count();
                if (matches >= 2) {
                    context.fill(slot.x, slot.y, slot.x + 16, slot.y + 16, 0xAA00FFAA);
                }
            }
        }
    }

    public static boolean shouldCancelClick(HandledScreen<?> screen, int slotId) {
        if (!BefConfig.INSTANCE.preventExperimentMissclicks) return false;
        String title = ScoreboardUtils.stripColor(screen.getTitle().getString());

        if (title.contains("Chronomatron") && BefConfig.INSTANCE.chronomatronSolver) {
            if (chronomatronStep < chronomatronOrder.size() && chronomatronOrder.get(chronomatronStep) != slotId) {
                return true;
            }
            chronomatronStep++;
        }

        if (title.contains("Ultrasequencer") && BefConfig.INSTANCE.ultrasequencerSolver && !ultrasequencerOrder.isEmpty()) {
            int minOrder = ultrasequencerOrder.values().stream().min(Comparator.naturalOrder()).orElse(1);
            Integer clickedOrder = ultrasequencerOrder.get(slotId);
            return clickedOrder == null || clickedOrder != minOrder;
        }

        return false;
    }
}
