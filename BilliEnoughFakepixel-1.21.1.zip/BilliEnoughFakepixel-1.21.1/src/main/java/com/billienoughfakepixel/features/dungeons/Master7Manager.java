package com.billienoughfakepixel.features.dungeons;

import com.billienoughfakepixel.config.BefConfig;
import com.billienoughfakepixel.utils.RenderUtils;
import com.billienoughfakepixel.utils.ScoreboardUtils;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Master7Manager {
    private record DragonHighlight(Box box, Vec3d pos, int color) {}
    private static final List<DragonHighlight> cachedDragons = new ArrayList<>();

    private static final Map<String, Vec3d> RELIC_WAYPOINTS = Map.of(
            "§5Purple Relic", new Vec3d(56, 8, 132),
            "§cRed Relic", new Vec3d(20, 7, 59),
            "§6Orange Relic", new Vec3d(92, 6, 56),
            "§bBlue Relic", new Vec3d(91, 6, 94),
            "§aGreen Relic", new Vec3d(20, 6, 94)
    );

    public static void onTick(MinecraftClient client) {
        cachedDragons.clear();
        if (client.world == null || !ScoreboardUtils.isMasterMode7()) return;
        if (BefConfig.INSTANCE.m7DragonHighlight) {
            for (Entity e : client.world.getEntities()) {
                if (e instanceof EnderDragonEntity dragon) {
                    int color = getDragonColor(dragon.getPos());
                    cachedDragons.add(new DragonHighlight(dragon.getBoundingBox().expand(1.0), dragon.getPos(), color));
                }
            }
        }
    }

    public static void onWorldRender(WorldRenderContext context) {
        if (!ScoreboardUtils.isMasterMode7()) return;
        BefConfig cfg = BefConfig.INSTANCE;

        if (cfg.m7DragonHighlight) {
            for (DragonHighlight d : cachedDragons) {
                RenderUtils.drawBoxOutline(context, d.box(), d.color(), true);
                RenderUtils.drawTracer(context, d.pos(), d.color());
            }
        }

        if (cfg.m7RelicWaypoints) {
            for (var entry : RELIC_WAYPOINTS.entrySet()) {
                RenderUtils.drawWaypointLabel(context, entry.getValue(), entry.getKey(), 0xFFFFFFFF);
            }
        }
    }

    private static int getDragonColor(Vec3d pos) {
        if (pos.x < 45 && pos.z < 75) return 0xFFFF4444;     // Power (Red)
        if (pos.x > 65 && pos.z < 75) return 0xFFFFAA00;     // Flame (Orange)
        if (pos.x > 65 && pos.z > 75) return 0xFF55FFFF;     // Ice (Aqua)
        if (pos.x < 45 && pos.z > 75) return 0xFF55FF55;     // Apex (Green)
        return 0xFFAA00FF;                                   // Soul (Purple)
    }
}
