package com.billienoughfakepixel.features.dungeons;

import com.billienoughfakepixel.config.BefConfig;
import com.billienoughfakepixel.utils.ItemUtils;
import com.billienoughfakepixel.utils.RenderUtils;
import com.billienoughfakepixel.utils.ScoreboardUtils;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.Entity;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

public class Floor7Manager {
    private static int terminalsDone = 0;
    private static int devicesDone = 0;
    private static int leversDone = 0;
    private static final List<Box> cachedWitherBoxes = new ArrayList<>();

    // Standard F7/M7 Phase 3 Terminal Waypoints
    private static final List<Vec3d> TERMINAL_WAYPOINTS = List.of(
            new Vec3d(111, 113, 73), new Vec3d(111, 119, 79), new Vec3d(89, 112, 92), new Vec3d(89, 122, 101),
            new Vec3d(68, 109, 121), new Vec3d(59, 120, 122), new Vec3d(47, 109, 121), new Vec3d(39, 108, 143),
            new Vec3d(-3, 109, 112), new Vec3d(-3, 119, 93), new Vec3d(19, 123, 93), new Vec3d(-3, 109, 77),
            new Vec3d(41, 109, 29), new Vec3d(44, 121, 29), new Vec3d(67, 109, 29), new Vec3d(72, 115, 48)
    );

    public static void onTick(MinecraftClient client) {
        if (!ScoreboardUtils.isInDungeons()) {
            terminalsDone = 0;
            devicesDone = 0;
            leversDone = 0;
            cachedWitherBoxes.clear();
            return;
        }
        if (client.world != null && ScoreboardUtils.isFloor7OrMaster7() && BefConfig.INSTANCE.boxWithers) {
            cachedWitherBoxes.clear();
            for (Entity e : client.world.getEntities()) {
                if (e instanceof WitherEntity) {
                    cachedWitherBoxes.add(e.getBoundingBox().expand(0.3));
                }
            }
        }
    }

    public static void onWorldRender(WorldRenderContext context) {
        if (!ScoreboardUtils.isFloor7OrMaster7()) return;
        BefConfig cfg = BefConfig.INSTANCE;

        if (cfg.boxWithers) {
            for (Box box : cachedWitherBoxes) {
                RenderUtils.drawBoxOutline(context, box, 0xFFFF3333, true);
            }
        }

        if (cfg.terminalWaypoints) {
            for (int i = 0; i < TERMINAL_WAYPOINTS.size(); i++) {
                Vec3d wp = TERMINAL_WAYPOINTS.get(i);
                RenderUtils.drawWaypointLabel(context, wp, "§bTerminal #" + (i + 1), 0xFF55FFFF);
            }
        }
    }

    public static void onHudRender(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || !ScoreboardUtils.isFloor7OrMaster7()) return;

        if (BefConfig.INSTANCE.terminalTracker) {
            int x = 10;
            int y = 128;
            context.fill(x - 2, y - 2, x + 110, y + 36, 0x8010141C);
            context.drawTextWithShadow(client.textRenderer, "§6§lBEF P3 Tracker", x + 2, y, 0xFFFFFFFF);
            context.drawTextWithShadow(client.textRenderer, "§aTerminals: §f" + terminalsDone + "/4", x + 2, y + 12, 0xFFFFFFFF);
            context.drawTextWithShadow(client.textRenderer, "§bDev/Levers: §f" + devicesDone + " / " + leversDone, x + 2, y + 24, 0xFFFFFFFF);
        }
    }

    public static void onChatMessage(String raw) {
        String clean = ScoreboardUtils.stripColor(raw);
        if (clean.contains("activated a terminal!")) terminalsDone++;
        else if (clean.contains("completed a device!")) devicesDone++;
        else if (clean.contains("activated a lever!")) leversDone++;
        if (clean.contains("The gate has been destroyed!")) {
            terminalsDone = 0;
            devicesDone = 0;
            leversDone = 0;
        }
    }

    public static void renderLeapSlot(DrawContext context, HandledScreen<?> screen, Slot slot) {
        BefConfig cfg = BefConfig.INSTANCE;
        if (!cfg.customLeapGui) return;
        String title = ScoreboardUtils.stripColor(screen.getTitle().getString());
        if (!title.contains("Spirit Leap") && !title.contains("Teleport to Player")) return;

        ItemStack stack = slot.getStack();
        if (stack.isEmpty() || !stack.isOf(Items.PLAYER_HEAD)) return;

        String playerName = ScoreboardUtils.stripColor(stack.getName().getString());
        int classColor = 0xFFAAAAAA;
        String classTag = "";

        if (cfg.leapGuiClassColors) {
            String detectedClass = detectPlayerDungeonClass(playerName, ItemUtils.getLoreLines(stack));
            switch (detectedClass) {
                case "Archer" -> { classColor = cfg.archerColor; classTag = "§cA"; }
                case "Berserk" -> { classColor = cfg.berserkColor; classTag = "§6B"; }
                case "Mage" -> { classColor = cfg.mageColor; classTag = "§bM"; }
                case "Healer" -> { classColor = cfg.healerColor; classTag = "§dH"; }
                case "Tank" -> { classColor = cfg.tankColor; classTag = "§aT"; }
            }
        }

        int tint = (classColor & 0x00FFFFFF) | 0x55000000;
        context.fill(slot.x, slot.y, slot.x + 16, slot.y + 16, tint);
        context.drawBorder(slot.x - 1, slot.y - 1, 18, 18, classColor);
        if (!classTag.isEmpty()) {
            context.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, classTag, slot.x + 1, slot.y + 1, 0xFFFFFFFF);
        }
    }

    private static String detectPlayerDungeonClass(String playerName, List<String> lore) {
        for (String line : lore) {
            for (String cls : List.of("Archer", "Berserk", "Mage", "Healer", "Tank")) {
                if (line.contains(cls)) return cls;
            }
        }
        for (String tab : ScoreboardUtils.getTabListLines()) {
            if (tab.contains(playerName)) {
                for (String cls : List.of("Archer", "Berserk", "Mage", "Healer", "Tank")) {
                    if (tab.contains(cls)) return cls;
                }
            }
        }
        return "";
    }

    public static void renderTerminalSlot(DrawContext context, HandledScreen<?> screen, Slot slot) {
        BefConfig cfg = BefConfig.INSTANCE;
        if (!cfg.terminalSolvers && !cfg.customTerminalGui) return;
        String title = ScoreboardUtils.stripColor(screen.getTitle().getString());
        ItemStack st = slot.getStack();
        if (st.isEmpty() || slot.id >= 54) return;

        if (title.contains("Correct all the panes!")) {
            if (st.isOf(Items.RED_STAINED_GLASS_PANE)) {
                context.fill(slot.x, slot.y, slot.x + 16, slot.y + 16, 0xAA00FF00);
            }
        } else if (title.contains("Click in order!")) {
            if (st.isOf(Items.RED_STAINED_GLASS_PANE)) {
                int min = Integer.MAX_VALUE;
                for (Slot s : screen.getScreenHandler().slots) {
                    if (s.id < 54 && s.getStack().isOf(Items.RED_STAINED_GLASS_PANE)) {
                        min = Math.min(min, s.getStack().getCount());
                    }
                }
                if (st.getCount() == min) {
                    context.fill(slot.x, slot.y, slot.x + 16, slot.y + 16, 0xAA00FF00);
                }
            }
        } else if (title.startsWith("What starts with:")) {
            String letter = title.replace("What starts with:", "").replace("'", "").trim().toLowerCase();
            String itemName = ScoreboardUtils.stripColor(st.getName().getString()).toLowerCase();
            if (!st.hasGlint() && !letter.isEmpty() && itemName.startsWith(letter)) {
                context.fill(slot.x, slot.y, slot.x + 16, slot.y + 16, 0xAA00FF00);
            }
        } else if (title.startsWith("Select all the")) {
            String colorWord = title.replace("Select all the", "").replace("items!", "").trim().toLowerCase();
            String itemId = st.getItem().toString().toLowerCase();
            if (!st.hasGlint() && itemId.contains(colorWord)) {
                context.fill(slot.x, slot.y, slot.x + 16, slot.y + 16, 0xAA00FF00);
            }
        } else if (title.contains("Click the button on time!")) {
            if (st.isOf(Items.LIME_TERRACOTTA) || st.isOf(Items.LIME_STAINED_GLASS_PANE)) {
                context.fill(slot.x, slot.y, slot.x + 16, slot.y + 16, 0xAA00FF00);
            }
        }
    }
}
