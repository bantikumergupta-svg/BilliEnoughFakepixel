package com.billienoughfakepixel.features.dungeons;

import com.billienoughfakepixel.config.BefConfig;
import com.billienoughfakepixel.utils.RenderUtils;
import com.billienoughfakepixel.utils.ScoreboardUtils;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.passive.BatEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

public class DungeonManager {
    private static final List<BlockPos> witherDoors = new ArrayList<>();
    private static final List<Box> cachedStarredMobBoxes = new ArrayList<>();
    private static final List<Box> cachedFelBoxes = new ArrayList<>();
    private static final List<Box> cachedBatBoxes = new ArrayList<>();
    private static Vec3d cachedSpiritBowPos = null;

    private static boolean sentSPlus = false;
    private static int currentScore = 0;
    private static String secretText = "Secrets: 0/0";
    private static int tickCounter = 0;

    public static void onTick(MinecraftClient client) {
        if (client.world == null || client.player == null) {
            sentSPlus = false;
            return;
        }
        if (!ScoreboardUtils.isInDungeons()) {
            sentSPlus = false;
            witherDoors.clear();
            cachedStarredMobBoxes.clear();
            cachedFelBoxes.clear();
            cachedBatBoxes.clear();
            cachedSpiritBowPos = null;
            return;
        }

        BefConfig cfg = BefConfig.INSTANCE;
        tickCounter++;

        // Update score & secrets every 10 ticks
        if (tickCounter % 10 == 0) {
            for (String line : ScoreboardUtils.getTabListLines()) {
                if (line.contains("Secrets Found:")) {
                    secretText = line.trim();
                }
            }
            for (String line : ScoreboardUtils.getSidebarLines()) {
                if (line.contains("Cleared:") && line.contains("(")) {
                    try {
                        String num = line.replaceAll(".*\\((\\d+)\\).*", "$1");
                        currentScore = Integer.parseInt(num);
                    } catch (NumberFormatException ignored) {}
                }
            }
        }

        // S+ Reminder & Custom S+ Message
        if (currentScore >= 300 && !sentSPlus) {
            sentSPlus = true;
            if (cfg.sPlusReminder) {
                client.inGameHud.setTitle(Text.literal("§6§lS+ REACHED! (300+)"));
                client.player.playSound(SoundEvents.ENTITY_PLAYER_LEVELUP, 1.0f, 1.2f);
            }
            if (cfg.customSPlusMessage && client.getNetworkHandler() != null && !cfg.sPlusMessageText.isBlank()) {
                client.getNetworkHandler().sendChatCommand("pc " + cfg.sPlusMessageText);
            }
        }

        // Auto Close Secret Chests & Auto Ready
        if (client.currentScreen instanceof HandledScreen<?> screen) {
            String title = ScoreboardUtils.stripColor(screen.getTitle().getString());
            if (cfg.autoCloseSecretChests && title.equals("Chest")) {
                client.player.closeHandledScreen();
            } else if (cfg.autoReady && title.contains("Catacombs Gate")) {
                for (Slot slot : screen.getScreenHandler().slots) {
                    if (slot.hasStack() && slot.getStack().isOf(Items.LIME_TERRACOTTA)) {
                        if (client.interactionManager != null) {
                            client.interactionManager.clickSlot(screen.getScreenHandler().syncId, slot.id, 0, SlotActionType.PICKUP, client.player);
                        }
                        break;
                    }
                }
            }
        }

        // Cache entity boxes on tick (adaptive interval for Poco X6 Pro & low-end phones)
        int entityScanInterval = cfg.lowEndMobileFastMode ? 5 : 2;
        if (tickCounter % entityScanInterval == 0) {
            cachedStarredMobBoxes.clear();
            cachedFelBoxes.clear();
            cachedBatBoxes.clear();
            cachedSpiritBowPos = null;

            double maxDistSq = cfg.lowEndMobileFastMode ? (36.0 * 36.0) : (48.0 * 48.0);
            for (Entity e : client.world.getEntities()) {
                if (e.squaredDistanceTo(client.player) > maxDistSq) continue;

                if (cfg.felPositionDisplay && e instanceof EndermanEntity) {
                    cachedFelBoxes.add(e.getBoundingBox());
                    continue;
                }
                if (cfg.batPositionDisplay && e instanceof BatEntity) {
                    cachedBatBoxes.add(e.getBoundingBox().expand(0.25));
                    continue;
                }
                if (e instanceof ArmorStandEntity) {
                    String name = ScoreboardUtils.stripColor(e.getName().getString());
                    if (cfg.starredMobDisplay && name.contains("✯")) {
                        cachedStarredMobBoxes.add(e.getBoundingBox().offset(0, -1.8, 0).expand(0.35, 0.9, 0.35));
                    } else if (cfg.spiritBowTracer && name.contains("Spirit Bow")) {
                        cachedSpiritBowPos = e.getPos();
                    }
                }
            }
        }

        // Scan Wither Doors with compact radius
        int doorScanInterval = cfg.lowEndMobileFastMode ? 40 : 25;
        if (cfg.witherDoorsHighlight && tickCounter % doorScanInterval == 0) {
            witherDoors.clear();
            BlockPos p = client.player.getBlockPos();
            int r = cfg.lowEndMobileFastMode ? 14 : 20;
            for (BlockPos pos : BlockPos.iterateOutwards(p, r, 4, r)) {
                if (client.world.getBlockState(pos).isOf(Blocks.COAL_BLOCK)
                        && client.world.getBlockState(pos.up()).isOf(Blocks.COAL_BLOCK)
                        && client.world.getBlockState(pos.down()).isOf(Blocks.COAL_BLOCK)) {
                    witherDoors.add(pos.toImmutable());
                }
            }
        }
    }

    public static void onWorldRender(WorldRenderContext context) {
        if (!ScoreboardUtils.isInDungeons()) return;
        BefConfig cfg = BefConfig.INSTANCE;

        if (cfg.witherDoorsHighlight) {
            for (BlockPos door : witherDoors) {
                RenderUtils.drawBoxOutline(context, new Box(door).expand(1.0, 1.5, 1.0), 0xFF222222, true);
            }
        }
        if (cfg.starredMobDisplay) {
            for (Box box : cachedStarredMobBoxes) {
                RenderUtils.drawBoxOutline(context, box, 0xFFFFAA00, true);
            }
        }
        if (cfg.felPositionDisplay) {
            for (Box box : cachedFelBoxes) {
                RenderUtils.drawBoxOutline(context, box, 0xFFAA00FF, true);
            }
        }
        if (cfg.batPositionDisplay) {
            for (Box box : cachedBatBoxes) {
                RenderUtils.drawBoxOutline(context, box, 0xFF55FF55, true);
            }
        }
        if (cfg.spiritBowTracer && cachedSpiritBowPos != null) {
            RenderUtils.drawTracer(context, cachedSpiritBowPos.add(0, 1.0, 0), 0xFFFF55FF);
            RenderUtils.drawWaypointLabel(context, cachedSpiritBowPos.add(0, 1.8, 0), "§d§lSpirit Bow", 0xFFFF55FF);
        }
    }

    public static void onHudRender(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        BefConfig cfg = BefConfig.INSTANCE;

        // Touch-friendly HUD badge in top-right corner when inventory/chat is open on Zalith Launcher
        if (client.currentScreen != null) {
            int w = client.getWindow().getScaledWidth();
            context.fill(w - 54, 4, w - 4, 20, 0xAA14171F);
            context.drawTextWithShadow(client.textRenderer, "§b[/bef]", w - 44, 8, 0xFFFFFFFF);
        }

        if (!ScoreboardUtils.isInDungeons()) return;

        // Dungeon Map HUD
        if (cfg.dungeonMap) {
            int mapX = 8;
            int mapY = 8;
            int size = 80;
            context.fill(mapX, mapY, mapX + size, mapY + size, 0x90101218);
            context.drawBorder(mapX, mapY, size, size, 0xFF4A5568);
            context.drawTextWithShadow(client.textRenderer, "§bBEF Map", mapX + 4, mapY + 4, 0xFFFFFFFF);
            int px = mapX + size / 2;
            int py = mapY + size / 2;
            context.fill(px - 2, py - 2, px + 2, py + 2, 0xFF00FF00);
        }

        // Score & Secret Overlays
        int y = cfg.dungeonMap ? 94 : 10;
        if (cfg.scoreOverlay) {
            String rank = currentScore >= 300 ? "§6S+" : (currentScore >= 270 ? "§aS" : "§e" + currentScore);
            context.drawTextWithShadow(client.textRenderer, "§bScore: §f" + currentScore + " (" + rank + "§f)", 10, y, 0xFFFFFFFF);
            y += 12;
        }
        if (cfg.secretOverlay) {
            context.drawTextWithShadow(client.textRenderer, "§d" + secretText, 10, y, 0xFFFFFFFF);
        }
    }

    public static boolean onChatMessage(String raw) {
        String clean = ScoreboardUtils.stripColor(raw);
        MinecraftClient client = MinecraftClient.getInstance();

        if (BefConfig.INSTANCE.hideUnableToLocateSign && clean.contains("Unable to locate sign")) {
            return false;
        }

        if (BefConfig.INSTANCE.bloodReadyTitle && (clean.contains("That will be enough for now") || clean.contains("The BLOOD DOOR has been opened!"))) {
            if (client.player != null && clean.contains("That will be enough for now")) {
                client.inGameHud.setTitle(Text.literal("§c§lBLOOD READY!"));
                client.player.playSound(SoundEvents.ENTITY_WITHER_SPAWN, 0.7f, 1.2f);
            }
        }
        return true;
    }
}
