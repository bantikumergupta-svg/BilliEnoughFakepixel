package com.billienoughfakepixel.utils;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class ItemUtils {

    public static List<String> getLoreLines(ItemStack stack) {
        List<String> lines = new ArrayList<>();
        if (stack == null || stack.isEmpty()) return lines;
        LoreComponent lore = stack.get(DataComponentTypes.LORE);
        if (lore != null) {
            for (Text line : lore.lines()) {
                lines.add(ScoreboardUtils.stripColor(line.getString()));
            }
        }
        return lines;
    }

    public static String getSkyblockId(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return "";
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData != null) {
            NbtCompound nbt = customData.copyNbt();
            if (nbt.contains("ExtraAttributes")) {
                NbtCompound extra = nbt.getCompound("ExtraAttributes");
                if (extra.contains("id")) {
                    return extra.getString("id");
                }
            }
            if (nbt.contains("id")) {
                return nbt.getString("id");
            }
        }
        return "";
    }

    public static String getRarity(ItemStack stack) {
        List<String> lore = getLoreLines(stack);
        if (lore.isEmpty()) return "";
        String last = lore.get(lore.size() - 1).toUpperCase();
        if (last.contains("MYTHIC")) return "MYTHIC";
        if (last.contains("LEGENDARY")) return "LEGENDARY";
        if (last.contains("EPIC")) return "EPIC";
        if (last.contains("RARE")) return "RARE";
        if (last.contains("UNCOMMON")) return "UNCOMMON";
        if (last.contains("COMMON")) return "COMMON";
        return "";
    }

    public static boolean isTeleportOrAbilityItem(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        String name = ScoreboardUtils.stripColor(stack.getName().getString()).toLowerCase();
        String id = getSkyblockId(stack).toUpperCase();
        return name.contains("aspect of the end")
                || name.contains("aspect of the void")
                || name.contains("hyperion")
                || name.contains("scylla")
                || name.contains("astraea")
                || name.contains("valkyrie")
                || name.contains("flower of truth")
                || name.contains("spirit sceptre")
                || name.contains("gyro")
                || name.contains("jerry-chine")
                || id.contains("ASPECT_OF_THE_");
    }
}
