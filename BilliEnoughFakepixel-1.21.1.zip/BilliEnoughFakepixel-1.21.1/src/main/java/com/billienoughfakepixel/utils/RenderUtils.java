package com.billienoughfakepixel.utils;

import com.billienoughfakepixel.config.BefConfig;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * Optimized for Poco X6 Pro (Mali-G615), Low-End Mobile GPUs, MobileGlues, and GL4ES.
 * When MobileGlues / GL4ES Safe Mode is enabled, avoids mid-buffer RenderSystem depth toggles
 * that can cause GL state stalls or depth-buffer corruption on GL4ES and MobileGlues.
 */
public class RenderUtils {

    private static double getMaxRenderDistSq() {
        return BefConfig.INSTANCE.lowEndMobileFastMode ? (36.0 * 36.0) : (64.0 * 64.0);
    }

    public static void drawBoxOutline(WorldRenderContext context, Box box, int argb, boolean throughWalls) {
        MatrixStack matrices = context.matrixStack();
        VertexConsumerProvider consumers = context.consumers();
        if (matrices == null || consumers == null) return;

        Vec3d cam = context.camera().getPos();
        if (cam.squaredDistanceTo(box.getCenter()) > getMaxRenderDistSq()) return;
        Box shifted = box.offset(-cam.x, -cam.y, -cam.z);

        float a = ((argb >> 24) & 0xFF) / 255.0f;
        float r = ((argb >> 16) & 0xFF) / 255.0f;
        float g = ((argb >> 8) & 0xFF) / 255.0f;
        float b = (argb & 0xFF) / 255.0f;

        boolean safeGl = BefConfig.INSTANCE.mobileGluesGl4esSafeMode;
        if (throughWalls && !safeGl) {
            RenderSystem.disableDepthTest();
        }
        VertexConsumer lines = consumers.getBuffer(RenderLayer.getLines());
        WorldRenderer.drawBox(matrices, lines, shifted, r, g, b, a);
        if (throughWalls && !safeGl) {
            RenderSystem.enableDepthTest();
        }
    }

    public static void drawBlockOutline(WorldRenderContext context, BlockPos pos, int argb, boolean throughWalls) {
        drawBoxOutline(context, new Box(pos), argb, throughWalls);
    }

    public static void drawFilledBox(WorldRenderContext context, Box box, int argb, boolean throughWalls) {
        // On Low-End Mobile Fast Mode, skip translucent filled quads to save fill-rate on GL4ES
        if (BefConfig.INSTANCE.lowEndMobileFastMode) {
            drawBoxOutline(context, box, argb | 0xFF000000, throughWalls);
            return;
        }

        MatrixStack matrices = context.matrixStack();
        VertexConsumerProvider consumers = context.consumers();
        if (matrices == null || consumers == null) return;

        Vec3d cam = context.camera().getPos();
        if (cam.squaredDistanceTo(box.getCenter()) > getMaxRenderDistSq()) return;
        Box shifted = box.offset(-cam.x, -cam.y, -cam.z);

        float a = ((argb >> 24) & 0xFF) / 255.0f;
        float r = ((argb >> 16) & 0xFF) / 255.0f;
        float g = ((argb >> 8) & 0xFF) / 255.0f;
        float b = (argb & 0xFF) / 255.0f;

        boolean safeGl = BefConfig.INSTANCE.mobileGluesGl4esSafeMode;
        if (throughWalls && !safeGl) {
            RenderSystem.disableDepthTest();
        }
        VertexConsumer buf = consumers.getBuffer(RenderLayer.getDebugFilledBox());
        WorldRenderer.renderFilledBox(matrices, buf,
                shifted.minX, shifted.minY, shifted.minZ,
                shifted.maxX, shifted.maxY, shifted.maxZ,
                r, g, b, a);
        if (throughWalls && !safeGl) {
            RenderSystem.enableDepthTest();
        }
    }

    public static void drawTracer(WorldRenderContext context, Vec3d target, int argb) {
        MatrixStack matrices = context.matrixStack();
        VertexConsumerProvider consumers = context.consumers();
        if (matrices == null || consumers == null) return;

        Camera camera = context.camera();
        Vec3d camPos = camera.getPos();
        if (camPos.squaredDistanceTo(target) > 80 * 80) return;
        Vec3d start = Vec3d.fromPolar(camera.getPitch(), camera.getYaw()).multiply(0.5);
        Vec3d end = target.subtract(camPos);

        float a = ((argb >> 24) & 0xFF) / 255.0f;
        float r = ((argb >> 16) & 0xFF) / 255.0f;
        float g = ((argb >> 8) & 0xFF) / 255.0f;
        float b = (argb & 0xFF) / 255.0f;

        boolean safeGl = BefConfig.INSTANCE.mobileGluesGl4esSafeMode;
        if (!safeGl) {
            RenderSystem.disableDepthTest();
        }
        VertexConsumer lines = consumers.getBuffer(RenderLayer.getLines());
        MatrixStack.Entry entry = matrices.peek();
        Vec3d dir = end.subtract(start).normalize();
        lines.vertex(entry, (float) start.x, (float) start.y, (float) start.z)
                .color(r, g, b, a)
                .normal(entry, (float) dir.x, (float) dir.y, (float) dir.z);
        lines.vertex(entry, (float) end.x, (float) end.y, (float) end.z)
                .color(r, g, b, a)
                .normal(entry, (float) dir.x, (float) dir.y, (float) dir.z);
        if (!safeGl) {
            RenderSystem.enableDepthTest();
        }
    }

    public static void drawWaypointLabel(WorldRenderContext context, Vec3d pos, String label, int argb) {
        MinecraftClient client = MinecraftClient.getInstance();
        MatrixStack matrices = context.matrixStack();
        VertexConsumerProvider consumers = context.consumers();
        if (matrices == null || consumers == null) return;

        Camera camera = context.camera();
        Vec3d camPos = camera.getPos();
        double distSq = camPos.squaredDistanceTo(pos);
        double maxDistSq = BefConfig.INSTANCE.lowEndMobileFastMode ? (48.0 * 48.0) : (90.0 * 90.0);
        if (distSq > maxDistSq) return;
        double dist = Math.sqrt(distSq);
        float scale = (float) Math.max(0.025, dist * 0.0032);

        matrices.push();
        matrices.translate(pos.x - camPos.x, pos.y - camPos.y, pos.z - camPos.z);
        matrices.multiply(camera.getRotation());
        matrices.scale(-scale, -scale, scale);

        TextRenderer tr = client.textRenderer;
        float x = -tr.getWidth(label) / 2.0f;
        // TextLayerType.SEE_THROUGH is natively supported by MobileGlues & GL4ES without manual depth toggling
        tr.draw(label, x, 0, argb, true, matrices.peek().getPositionMatrix(),
                consumers, TextRenderer.TextLayerType.SEE_THROUGH, 0x60000000, 0xF000F0);
        matrices.pop();
    }
}
