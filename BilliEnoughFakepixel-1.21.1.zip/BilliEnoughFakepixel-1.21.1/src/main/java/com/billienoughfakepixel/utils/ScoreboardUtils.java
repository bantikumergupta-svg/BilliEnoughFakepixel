package com.billienoughfakepixel.utils;

import com.billienoughfakepixel.config.BefConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class ScoreboardUtils {
    private static final Pattern STRIP_COLOR = Pattern.compile("(?i)§[0-9A-FK-OR]");

    // Cached scoreboard & tab state (throttled to avoid mobile CPU spikes)
    private static List<String> cachedSidebar = new ArrayList<>();
    private static List<String> cachedTabList = new ArrayList<>();
    private static boolean cachedInSkyblock = false;
    private static boolean cachedInDungeons = false;
    private static String cachedFloor = "";
    private static long lastCacheUpdateTick = -1;

    public static String stripColor(String input) {
        return input == null ? "" : STRIP_COLOR.matcher(input).replaceAll("");
    }

    public static void updateCacheIfNeeded() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) {
            cachedSidebar.clear();
            cachedTabList.clear();
            cachedInSkyblock = false;
            cachedInDungeons = false;
            cachedFloor = "";
            return;
        }
        long time = client.world.getTime();
        int interval = BefConfig.INSTANCE.lowEndMobileFastMode ? 20 : 10;
        if (time - lastCacheUpdateTick < interval && lastCacheUpdateTick != -1) {
            return;
        }
        lastCacheUpdateTick = time;

        List<String> lines = new ArrayList<>(16);
        Scoreboard scoreboard = client.world.getScoreboard();
        ScoreboardObjective objective = scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
        if (objective != null) {
            String title = stripColor(objective.getDisplayName().getString()).toUpperCase();
            cachedInSkyblock = title.contains("SKYBLOCK") || title.contains("FAKEPIXEL");
            for (ScoreboardEntry entry : scoreboard.getScoreboardEntries(objective)) {
                if (entry.hidden()) continue;
                Team team = scoreboard.getScoreHolderTeam(entry.owner());
                String line = Team.decorateName(team, entry.name()).getString();
                lines.add(stripColor(line).trim());
            }
        } else {
            cachedInSkyblock = false;
        }
        cachedSidebar = lines;

        boolean dungeons = false;
        String floor = "";
        for (String line : cachedSidebar) {
            if (line.contains("The Catacombs") || line.contains("Cleared:") || line.contains("Time Elapsed:")) {
                dungeons = true;
            }
            if (line.contains("The Catacombs")) {
                int idx = line.indexOf('(');
                int end = line.indexOf(')');
                if (idx != -1 && end > idx) {
                    floor = line.substring(idx + 1, end).trim();
                }
            }
        }
        cachedInDungeons = dungeons;
        cachedFloor = floor;

        List<String> tab = new ArrayList<>(24);
        if (client.getNetworkHandler() != null) {
            for (PlayerListEntry entry : client.getNetworkHandler().getPlayerList()) {
                Text display = entry.getDisplayName();
                if (display != null) {
                    tab.add(stripColor(display.getString()).trim());
                } else if (entry.getProfile() != null) {
                    tab.add(entry.getProfile().getName());
                }
            }
        }
        cachedTabList = tab;
    }

    public static List<String> getSidebarLines() {
        updateCacheIfNeeded();
        return cachedSidebar;
    }

    public static boolean isInFakepixelSkyblock() {
        updateCacheIfNeeded();
        return cachedInSkyblock;
    }

    public static boolean isInDungeons() {
        updateCacheIfNeeded();
        return cachedInDungeons;
    }

    public static String getDungeonFloor() {
        updateCacheIfNeeded();
        return cachedFloor;
    }

    public static boolean isFloor7OrMaster7() {
        String floor = getDungeonFloor().toUpperCase();
        return floor.equals("F7") || floor.equals("M7");
    }

    public static boolean isMasterMode7() {
        return getDungeonFloor().equalsIgnoreCase("M7");
    }

    public static List<String> getTabListLines() {
        updateCacheIfNeeded();
        return cachedTabList;
    }
}
