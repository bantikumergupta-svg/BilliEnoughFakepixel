package com.billienoughfakepixel.mixin;

import com.billienoughfakepixel.config.BefConfig;
import com.billienoughfakepixel.features.dungeons.Floor7Manager;
import com.billienoughfakepixel.features.experimentation.ExperimentationSolver;
import com.billienoughfakepixel.utils.ItemUtils;
import com.billienoughfakepixel.utils.ScoreboardUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HandledScreen.class)
public class MixinHandledScreen {

    @Inject(method = "drawSlot", at = @At("TAIL"))
    private void onDrawSlot(DrawContext context, Slot slot, CallbackInfo ci) {
        HandledScreen<?> screen = (HandledScreen<?>) (Object) this;
        String title = ScoreboardUtils.stripColor(screen.getTitle().getString());

        ExperimentationSolver.renderSlotOverlay(context, screen, slot);
        Floor7Manager.renderTerminalSlot(context, screen, slot);
        Floor7Manager.renderLeapSlot(context, screen, slot);

        if (BefConfig.INSTANCE.reforgeHelper && title.contains("Reforge")) {
            ItemStack st = slot.getStack();
            if (!st.isEmpty()) {
                String name = ScoreboardUtils.stripColor(st.getName().getString());
                if (name.contains("Ancient") || name.contains("Withered") || name.contains("Fabled")
                        || name.contains("Necrotic") || name.contains("Spiritual") || name.contains("Jaded")) {
                    context.fill(slot.x, slot.y, slot.x + 16, slot.y + 16, 0x8000FF00);
                }
            }
        }

        if (BefConfig.INSTANCE.missingAccessoriesGui && title.contains("Accessory Bag")) {
            ItemStack st = slot.getStack();
            if (!st.isEmpty()) {
                String rarity = ItemUtils.getRarity(st);
                if (rarity.equals("COMMON") || rarity.equals("UNCOMMON")) {
                    context.drawBorder(slot.x, slot.y, 16, 16, 0xFFFFAA00);
                }
            }
        }
    }

    @Inject(method = "onMouseClick(Lnet/minecraft/screen/slot/Slot;IILnet/minecraft/screen/slot/SlotActionType;)V",
            at = @At("HEAD"), cancellable = true)
    private void onMouseClick(Slot slot, int slotId, int button, SlotActionType actionType, CallbackInfo ci) {
        if (slot == null) return;
        HandledScreen<?> screen = (HandledScreen<?>) (Object) this;
        String title = ScoreboardUtils.stripColor(screen.getTitle().getString());

        if (ExperimentationSolver.shouldCancelClick(screen, slot.id)) {
            ci.cancel();
            return;
        }

        if (title.contains("Salvage") && slot.hasStack()) {
            String rarity = ItemUtils.getRarity(slot.getStack());
            BefConfig cfg = BefConfig.INSTANCE;
            if ((cfg.preventSalvagingEpic && rarity.equals("EPIC"))
                    || (cfg.preventSalvagingLegendary && rarity.equals("LEGENDARY"))
                    || (cfg.preventSalvagingMythic && rarity.equals("MYTHIC"))) {
                MinecraftClient client = MinecraftClient.getInstance();
                if (client.player != null) {
                    client.player.sendMessage(Text.literal("§c[BEF] Blocked salvaging " + rarity + " item!"), true);
                }
                ci.cancel();
            }
        }
    }

    @ModifyVariable(method = "onMouseClick(Lnet/minecraft/screen/slot/Slot;IILnet/minecraft/screen/slot/SlotActionType;)V",
            at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private SlotActionType modifyClickToMiddle(SlotActionType actionType, Slot slot, int slotId, int button) {
        if (BefConfig.INSTANCE.middleClickMenus && button == 0 && actionType == SlotActionType.PICKUP) {
            HandledScreen<?> screen = (HandledScreen<?>) (Object) this;
            String title = ScoreboardUtils.stripColor(screen.getTitle().getString());
            if (!title.contains("Inventory") && !title.contains("Chest") && !title.contains("Crafting")) {
                return SlotActionType.CLONE;
            }
        }
        return actionType;
    }
}
