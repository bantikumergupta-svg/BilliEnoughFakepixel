package com.billienoughfakepixel.mixin;

import com.billienoughfakepixel.config.BefConfig;
import net.minecraft.block.BlockState;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ParticleManager.class)
public class MixinParticleManager {

    @Inject(method = "addBlockBreakParticles", at = @At("HEAD"), cancellable = true)
    private void onBlockBreakParticles(BlockPos pos, BlockState state, CallbackInfo ci) {
        if (BefConfig.INSTANCE.disableBlockBreakingParticles) {
            ci.cancel();
        }
    }

    @Inject(method = "addBlockBreakingEffects", at = @At("HEAD"), cancellable = true)
    private void onBlockBreakingEffects(BlockPos pos, Direction direction, CallbackInfo ci) {
        if (BefConfig.INSTANCE.disableBlockBreakingParticles) {
            ci.cancel();
        }
    }

    @Inject(method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
            at = @At("HEAD"), cancellable = true)
    private void onAddParticle(ParticleEffect parameters, double x, double y, double z,
                               double velocityX, double velocityY, double velocityZ,
                               CallbackInfoReturnable<Particle> cir) {
        BefConfig cfg = BefConfig.INSTANCE;
        var type = parameters.getType();
        if (cfg.disableHyperionExplosions && (type == ParticleTypes.EXPLOSION || type == ParticleTypes.EXPLOSION_EMITTER)) {
            cir.setReturnValue(null);
        } else if (cfg.hideFlamingFists && (type == ParticleTypes.FLAME || type == ParticleTypes.SMALL_FLAME)) {
            cir.setReturnValue(null);
        } else if (cfg.disableThunderlordBolts && type == ParticleTypes.ELECTRIC_SPARK) {
            cir.setReturnValue(null);
        } else if (cfg.midasStaffMinimal && type == ParticleTypes.SMOKE) {
            cir.setReturnValue(null);
        }
    }
}
