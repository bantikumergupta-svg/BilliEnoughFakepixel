package com.billienoughfakepixel.mixin;

import com.billienoughfakepixel.config.BefConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderer.class)
public class MixinEntityRenderer<T extends Entity> {

    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private void onShouldRender(T entity, Frustum frustum, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
        BefConfig cfg = BefConfig.INSTANCE;
        if (cfg.hideDeadMobs && entity instanceof LivingEntity living && living.isDead()) {
            cir.setReturnValue(false);
            return;
        }
        if (cfg.hideFallingBlocks && entity instanceof FallingBlockEntity) {
            cir.setReturnValue(false);
            return;
        }
        if (cfg.hidePlayersCloseToNpcs && entity instanceof PlayerEntity p && p != MinecraftClient.getInstance().player) {
            if (MinecraftClient.getInstance().player != null && p.squaredDistanceTo(MinecraftClient.getInstance().player) < 16 * 16) {
                if (p.getWorld() != null && (!p.getWorld().getEntitiesByClass(VillagerEntity.class, p.getBoundingBox().expand(2.2), v -> true).isEmpty()
                        || !p.getWorld().getEntitiesByClass(ArmorStandEntity.class, p.getBoundingBox().expand(1.5), a -> a.hasCustomName()).isEmpty())) {
                    cir.setReturnValue(false);
                }
            }
        }
    }
}
