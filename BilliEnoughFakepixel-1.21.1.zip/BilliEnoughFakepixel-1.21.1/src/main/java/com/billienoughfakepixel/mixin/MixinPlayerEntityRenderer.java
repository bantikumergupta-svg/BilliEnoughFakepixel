package com.billienoughfakepixel.mixin;

import com.billienoughfakepixel.config.BefConfig;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntityRenderer.class)
public class MixinPlayerEntityRenderer {

    @Inject(method = "scale(Lnet/minecraft/client/network/AbstractClientPlayerEntity;Lnet/minecraft/client/util/math/MatrixStack;F)V",
            at = @At("TAIL"))
    private void onScale(AbstractClientPlayerEntity player, MatrixStack matrices, float amount, CallbackInfo ci) {
        if (BefConfig.INSTANCE.smolPeople) {
            float s = BefConfig.INSTANCE.smolPeopleScale;
            matrices.scale(s, s, s);
        }
    }

    @Inject(method = "setModelPose", at = @At("TAIL"))
    private void onSetModelPose(AbstractClientPlayerEntity player, CallbackInfo ci) {
        if (BefConfig.INSTANCE.hidePlayerArmor) {
            var model = ((PlayerEntityRenderer) (Object) this).getModel();
            model.hat.visible = false;
            model.jacket.visible = false;
            model.leftPants.visible = false;
            model.rightPants.visible = false;
            model.leftSleeve.visible = false;
            model.rightSleeve.visible = false;
        }
    }
}
