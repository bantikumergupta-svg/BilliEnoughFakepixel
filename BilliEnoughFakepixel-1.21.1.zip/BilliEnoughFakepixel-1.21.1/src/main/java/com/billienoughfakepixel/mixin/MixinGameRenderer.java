package com.billienoughfakepixel.mixin;

import com.billienoughfakepixel.BilliEnoughFakepixelClient;
import com.billienoughfakepixel.config.BefConfig;
import com.billienoughfakepixel.features.qol.QolManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public class MixinGameRenderer {

    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
    private void onTiltViewWhenHurt(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        if (BefConfig.INSTANCE.noHurtCamera) {
            ci.cancel();
        }
    }

    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void onGetFov(Camera camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Double> cir) {
        if (!BefConfig.INSTANCE.etherwarpZoom) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null && BilliEnoughFakepixelClient.etherwarpZoomKey.isPressed()
                && QolManager.isEtherwarpItem(client.player.getMainHandStack())) {
            cir.setReturnValue((double) BefConfig.INSTANCE.etherwarpZoomFov);
        }
    }
}
