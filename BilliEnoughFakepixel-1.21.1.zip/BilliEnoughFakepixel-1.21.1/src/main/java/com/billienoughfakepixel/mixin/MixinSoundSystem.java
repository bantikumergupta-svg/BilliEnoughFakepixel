package com.billienoughfakepixel.mixin;

import com.billienoughfakepixel.config.BefConfig;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.sound.SoundSystem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SoundSystem.class)
public class MixinSoundSystem {

    @Inject(method = "play(Lnet/minecraft/client/sound/SoundInstance;)V", at = @At("HEAD"), cancellable = true)
    private void onPlaySound(SoundInstance sound, CallbackInfo ci) {
        if (sound == null) return;
        String id = sound.getId().toString();
        BefConfig cfg = BefConfig.INSTANCE;

        if (cfg.disableJerryAoteSounds) {
            if (id.contains("entity.enderman.teleport") || id.contains("entity.villager.ambient") || id.contains("entity.ghast.scream")) {
                ci.cancel();
                return;
            }
        }
        if (cfg.midasStaffMinimal) {
            if (id.contains("entity.zombie.attack_iron_door") || id.contains("block.anvil.land")) {
                ci.cancel();
            }
        }
    }
}
