package com.billienoughfakepixel.mixin;

import com.billienoughfakepixel.config.BefConfig;
import com.billienoughfakepixel.utils.ScoreboardUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ChatHud.class)
public abstract class MixinChatHud {

    @Shadow
    public abstract Style getTextStyleAt(double x, double y);

    @Inject(method = "mouseClicked", at = @At("HEAD"))
    private void onMouseClicked(double mouseX, double mouseY, CallbackInfoReturnable<Boolean> cir) {
        if (!BefConfig.INSTANCE.copyChatMessage) return;
        MinecraftClient client = MinecraftClient.getInstance();
        Style style = getTextStyleAt(mouseX, mouseY);
        if (style != null && style.getHoverEvent() != null) {
            if (client.keyboard != null) {
                var value = style.getInsertion();
                if (value != null && !value.isEmpty()) {
                    client.keyboard.setClipboard(ScoreboardUtils.stripColor(value));
                    if (client.player != null) {
                        client.player.sendMessage(Text.literal("§a[BEF] Copied message to clipboard!"), true);
                    }
                }
            }
        }
    }
}
