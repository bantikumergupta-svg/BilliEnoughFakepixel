package com.billienoughfakepixel.gui;

import com.billienoughfakepixel.config.BefConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class BefConfigScreen extends Screen {
    private enum Category {
        QOL("QoL & Mobile"),
        DUNGEONS("Dungeons"),
        F7_M7("F7 & M7"),
        EXPERIMENTATION("Experimentation"),
        SLAYERS("Slayers");

        final String title;
        Category(String title) { this.title = title; }
    }

    private record ToggleOption(String name, String description, Supplier<Boolean> getter, Consumer<Boolean> setter) {}

    private final Screen parent;
    private Category activeCategory = Category.QOL;
    private TextFieldWidget searchField;
    private TextFieldWidget sPlusMessageField;
    private String searchQuery = "";
    private int scrollOffset = 0;

    private final List<ToggleOption> qolOptions = new ArrayList<>();
    private final List<ToggleOption> dungeonOptions = new ArrayList<>();
    private final List<ToggleOption> f7m7Options = new ArrayList<>();
    private final List<ToggleOption> experimentOptions = new ArrayList<>();
    private final List<ToggleOption> slayerOptions = new ArrayList<>();

    public BefConfigScreen(Screen parent) {
        super(Text.literal("BilliEnoughFakepixel Config"));
        this.parent = parent;
        populateOptions();
    }

    private void populateOptions() {
        BefConfig c = BefConfig.INSTANCE;

        // Mobile & Renderer Optimizations (Poco X6 Pro, Low-End Mobile, MobileGlues & GL4ES)
        qolOptions.add(new ToggleOption("MobileGlues / GL4ES Safe Mode", "Prevents GL state stalls & depth bugs on mobile renderers", () -> c.mobileGluesGl4esSafeMode, v -> c.mobileGluesGl4esSafeMode = v));
        qolOptions.add(new ToggleOption("Low-End Mobile Fast Mode", "Ultra-fast wireframe & throttled scan for low-end phones", () -> c.lowEndMobileFastMode, v -> c.lowEndMobileFastMode = v));

        // Quality of Life
        qolOptions.add(new ToggleOption("Disable Block Breaking Particles", "Hides block break particle clutter", () -> c.disableBlockBreakingParticles, v -> c.disableBlockBreakingParticles = v));
        qolOptions.add(new ToggleOption("Always Sprint", "Automatically holds sprint", () -> c.alwaysSprint, v -> c.alwaysSprint = v));
        qolOptions.add(new ToggleOption("Copy Chat Message", "Click chat messages to copy them", () -> c.copyChatMessage, v -> c.copyChatMessage = v));
        qolOptions.add(new ToggleOption("Full Block Lever", "Expands lever hitbox to a full block", () -> c.fullBlockLever, v -> c.fullBlockLever = v));
        qolOptions.add(new ToggleOption("Block Placing Items", "Prevents placing Skyblock ability items", () -> c.blockPlacingItems, v -> c.blockPlacingItems = v));
        qolOptions.add(new ToggleOption("Etherwarp Overlay", "Highlights target block for Etherwarp", () -> c.etherwarpOverlay, v -> c.etherwarpOverlay = v));
        qolOptions.add(new ToggleOption("Etherwarp Sounds", "Plays clean teleport chime on Etherwarp", () -> c.etherwarpSounds, v -> c.etherwarpSounds = v));
        qolOptions.add(new ToggleOption("Etherwarp Zoom", "Smooth zoom when holding Etherwarp", () -> c.etherwarpZoom, v -> c.etherwarpZoom = v));
        qolOptions.add(new ToggleOption("Hide Flaming Fists", "Hides flaming fist particle/render clutter", () -> c.hideFlamingFists, v -> c.hideFlamingFists = v));
        qolOptions.add(new ToggleOption("Hide Player Armor", "Hides armor models on players", () -> c.hidePlayerArmor, v -> c.hidePlayerArmor = v));
        qolOptions.add(new ToggleOption("Hide Dead Mobs", "Hides death animation of dead entities", () -> c.hideDeadMobs, v -> c.hideDeadMobs = v));
        qolOptions.add(new ToggleOption("Hide Falling Blocks", "Hides falling block entities", () -> c.hideFallingBlocks, v -> c.hideFallingBlocks = v));
        qolOptions.add(new ToggleOption("Item Animations", "Custom compact held item scale & swing", () -> c.itemAnimations, v -> c.itemAnimations = v));
        qolOptions.add(new ToggleOption("Smol People", "Scales player models smaller", () -> c.smolPeople, v -> c.smolPeople = v));
        qolOptions.add(new ToggleOption("Reforge Helper", "Highlights target reforges in menu", () -> c.reforgeHelper, v -> c.reforgeHelper = v));
        qolOptions.add(new ToggleOption("Disable Hyperion Explosions", "Hides Hyperion explosion particles", () -> c.disableHyperionExplosions, v -> c.disableHyperionExplosions = v));
        qolOptions.add(new ToggleOption("Disable Thunderlord Bolts", "Hides Thunderlord lightning bolts", () -> c.disableThunderlordBolts, v -> c.disableThunderlordBolts = v));
        qolOptions.add(new ToggleOption("No Hurt Camera", "Disables screen shake on damage", () -> c.noHurtCamera, v -> c.noHurtCamera = v));
        qolOptions.add(new ToggleOption("Fullbright", "Maximum brightness everywhere", () -> c.fullbright, v -> c.fullbright = v));
        qolOptions.add(new ToggleOption("Disable Potion Effects in Inv", "Hides potion list shifting inventory", () -> c.disablePotionEffectsInInventory, v -> c.disablePotionEffectsInInventory = v));
        qolOptions.add(new ToggleOption("Equipment Overlay", "Shows active equipment slots on screen", () -> c.equipmentOverlay, v -> c.equipmentOverlay = v));
        qolOptions.add(new ToggleOption("Middle Click on Menus", "Converts left clicks to middle clicks in GUIs", () -> c.middleClickMenus, v -> c.middleClickMenus = v));
        qolOptions.add(new ToggleOption("Disable Jerry-chine & AOTE Sounds", "Mutes noisy AOTE & Jerry-chine spam", () -> c.disableJerryAoteSounds, v -> c.disableJerryAoteSounds = v));
        qolOptions.add(new ToggleOption("Midas Staff Minimal", "Reduces Midas Staff particles & sounds", () -> c.midasStaffMinimal, v -> c.midasStaffMinimal = v));
        qolOptions.add(new ToggleOption("Wardrobe Key Shortcut", "Keybind to open /wardrobe", () -> c.wardrobeKeyShortcut, v -> c.wardrobeKeyShortcut = v));
        qolOptions.add(new ToggleOption("Equipment Key Shortcut", "Keybind to open /equipment", () -> c.equipmentKeyShortcut, v -> c.equipmentKeyShortcut = v));
        qolOptions.add(new ToggleOption("Hide Players Close to NPCs", "Hides players crowding around NPCs", () -> c.hidePlayersCloseToNpcs, v -> c.hidePlayersCloseToNpcs = v));
        qolOptions.add(new ToggleOption("Missing Accessories GUI (FIX)", "Highlights missing/upgradeable talismans", () -> c.missingAccessoriesGui, v -> c.missingAccessoriesGui = v));
        qolOptions.add(new ToggleOption("Show Ender Nodes", "Highlights Ender Nodes in The End", () -> c.showEnderNodes, v -> c.showEnderNodes = v));
        qolOptions.add(new ToggleOption("Disable Info & Watchdog Messages", "Filters Info & Watchdog chat spam", () -> c.disableInfoWatchdogMessages, v -> c.disableInfoWatchdogMessages = v));

        // Dungeons General + Starred Mobs
        dungeonOptions.add(new ToggleOption("Custom Leap GUI", "Clean card-based Spirit Leap overlay", () -> c.customLeapGui, v -> c.customLeapGui = v));
        dungeonOptions.add(new ToggleOption("Leap GUI Dungeon Class Colors", "Colors Leap cards by Archer/Bers/Mage/Healer/Tank", () -> c.leapGuiClassColors, v -> c.leapGuiClassColors = v));
        dungeonOptions.add(new ToggleOption("Blood Ready Title", "Shows title when Blood Room is ready", () -> c.bloodReadyTitle, v -> c.bloodReadyTitle = v));
        dungeonOptions.add(new ToggleOption("Boulder Solver", "Highlights correct chest & boulder steps", () -> c.boulderSolver, v -> c.boulderSolver = v));
        dungeonOptions.add(new ToggleOption("Silverfish Solver", "Draws optimal ice path for Silverfish", () -> c.silverfishSolver, v -> c.silverfishSolver = v));
        dungeonOptions.add(new ToggleOption("Teleport Maze Solver", "Marks visited & target pads in Teleport Maze", () -> c.teleportMazeSolver, v -> c.teleportMazeSolver = v));
        dungeonOptions.add(new ToggleOption("Three Weirdos Solver", "Highlights correct chest in Three Weirdos", () -> c.threeWeirdosSolver, v -> c.threeWeirdosSolver = v));
        dungeonOptions.add(new ToggleOption("Wither Doors Highlight", "Boxes Wither & Blood doors through walls", () -> c.witherDoorsHighlight, v -> c.witherDoorsHighlight = v));
        dungeonOptions.add(new ToggleOption("Spirit Bow Tracer", "Draws tracer line to Spirit Bow in F4/M4", () -> c.spiritBowTracer, v -> c.spiritBowTracer = v));
        dungeonOptions.add(new ToggleOption("Dungeon Map", "HUD Dungeon Map overlay", () -> c.dungeonMap, v -> c.dungeonMap = v));
        dungeonOptions.add(new ToggleOption("Auto Ready", "Automatically clicks Ready in dungeon start", () -> c.autoReady, v -> c.autoReady = v));
        dungeonOptions.add(new ToggleOption("Auto Close Secret Chests", "Automatically closes dungeon secret chests", () -> c.autoCloseSecretChests, v -> c.autoCloseSecretChests = v));
        dungeonOptions.add(new ToggleOption("Hide 'Unable to locate sign'", "Suppresses 'Unable to locate sign' chat error", () -> c.hideUnableToLocateSign, v -> c.hideUnableToLocateSign = v));
        dungeonOptions.add(new ToggleOption("Custom S+ Message", "Sends custom party message on S+ score", () -> c.customSPlusMessage, v -> c.customSPlusMessage = v));
        dungeonOptions.add(new ToggleOption("S+ Reminder", "Alerts when 300+ score is reached", () -> c.sPlusReminder, v -> c.sPlusReminder = v));
        dungeonOptions.add(new ToggleOption("Score Overlay", "Displays live dungeon score & breakdown", () -> c.scoreOverlay, v -> c.scoreOverlay = v));
        dungeonOptions.add(new ToggleOption("Secret Overlay", "Displays room & run secret counter", () -> c.secretOverlay, v -> c.secretOverlay = v));
        dungeonOptions.add(new ToggleOption("Prevent Salvaging Epic Items", "Blocks salvaging Epic gear", () -> c.preventSalvagingEpic, v -> c.preventSalvagingEpic = v));
        dungeonOptions.add(new ToggleOption("Prevent Salvaging Legendary Items", "Blocks salvaging Legendary gear", () -> c.preventSalvagingLegendary, v -> c.preventSalvagingLegendary = v));
        dungeonOptions.add(new ToggleOption("Prevent Salvaging Mythic Items", "Blocks salvaging Mythic gear", () -> c.preventSalvagingMythic, v -> c.preventSalvagingMythic = v));
        dungeonOptions.add(new ToggleOption("Starred Mob Display", "Boxes starred mobs through walls", () -> c.starredMobDisplay, v -> c.starredMobDisplay = v));
        dungeonOptions.add(new ToggleOption("Fel Position Display", "Highlights invisible/visible Fels", () -> c.felPositionDisplay, v -> c.felPositionDisplay = v));
        dungeonOptions.add(new ToggleOption("Bat Position Display", "Highlights secret bats in purple", () -> c.batPositionDisplay, v -> c.batPositionDisplay = v));

        // Floor 7 & Master Mode 7
        f7m7Options.add(new ToggleOption("Custom Terminal GUI", "Clean interactive overlay for F7 terminals", () -> c.customTerminalGui, v -> c.customTerminalGui = v));
        f7m7Options.add(new ToggleOption("Terminal Solvers", "Solves Melody, Order, Colors, Starts With, Rubix & Panes", () -> c.terminalSolvers, v -> c.terminalSolvers = v));
        f7m7Options.add(new ToggleOption("Terminal Waypoints", "3D waypoints for F7/M7 phase 3 terminals", () -> c.terminalWaypoints, v -> c.terminalWaypoints = v));
        f7m7Options.add(new ToggleOption("Terminal Tracker", "HUD tracker for terminals, devices & levers", () -> c.terminalTracker, v -> c.terminalTracker = v));
        f7m7Options.add(new ToggleOption("Box Withers (F7/M7)", "Highlights Maxor, Storm, Goldor & Necron", () -> c.boxWithers, v -> c.boxWithers = v));
        f7m7Options.add(new ToggleOption("M7 Dragon Highlight", "Color-coded bounding boxes for M7 dragons", () -> c.m7DragonHighlight, v -> c.m7DragonHighlight = v));
        f7m7Options.add(new ToggleOption("M7 Relic Waypoints", "Waypoints for M7 relics & cauldrons", () -> c.m7RelicWaypoints, v -> c.m7RelicWaypoints = v));

        // Experimentation Table
        experimentOptions.add(new ToggleOption("Chronomatron Solver", "Highlights next sequence in Chronomatron", () -> c.chronomatronSolver, v -> c.chronomatronSolver = v));
        experimentOptions.add(new ToggleOption("Ultrasequencer Solver", "Shows click order 1..N in Ultrasequencer", () -> c.ultrasequencerSolver, v -> c.ultrasequencerSolver = v));
        experimentOptions.add(new ToggleOption("Superpairs Solver", "Tracks revealed pairs & highlights matches", () -> c.superpairsSolver, v -> c.superpairsSolver = v));
        experimentOptions.add(new ToggleOption("Prevent Missclicks", "Blocks wrong clicks in Experimentation Table", () -> c.preventExperimentMissclicks, v -> c.preventExperimentMissclicks = v));

        // Slayers
        slayerOptions.add(new ToggleOption("Voidgloom Beacon Waypoint (BETA)", "Highlights & traces Voidgloom Yang Glyphs", () -> c.voidgloomBeaconWaypoint, v -> c.voidgloomBeaconWaypoint = v));
        slayerOptions.add(new ToggleOption("Miniboss Spawn Alert", "Title & sound alert on Slayer miniboss", () -> c.minibossSpawnAlert, v -> c.minibossSpawnAlert = v));
        slayerOptions.add(new ToggleOption("Slayer Health Display", "Shows active Slayer boss HP on HUD", () -> c.slayerHealthDisplay, v -> c.slayerHealthDisplay = v));
        slayerOptions.add(new ToggleOption("Slayer Boss Time", "Tracks time taken to kill Slayer boss", () -> c.slayerBossTime, v -> c.slayerBossTime = v));
        slayerOptions.add(new ToggleOption("Blaze Pillar Title", "Shows Fire Pillar countdown title", () -> c.blazePillarTitle, v -> c.blazePillarTitle = v));
        slayerOptions.add(new ToggleOption("Blaze Attunements", "Highlights Ashen/Auric/Crystal/Spirit attunement", () -> c.blazeAttunements, v -> c.blazeAttunements = v));
    }

    @Override
    protected void init() {
        rebuildWidgets();
    }

    private void rebuildWidgets() {
        clearChildren();

        int panelW = Math.min(540, this.width - 24);
        int panelH = Math.min(340, this.height - 24);
        int left = (this.width - panelW) / 2;
        int top = (this.height - panelH) / 2;

        // Category sidebar buttons
        int catY = top + 36;
        for (Category cat : Category.values()) {
            addDrawableChild(ButtonWidget.builder(Text.literal(cat.title), btn -> {
                activeCategory = cat;
                scrollOffset = 0;
                rebuildWidgets();
            }).dimensions(left + 8, catY, 115, 22).build());
            catY += 25;
        }

        // Touch-friendly ▲ Up / ▼ Down scroll buttons for Zalith Launcher mobile screens
        addDrawableChild(ButtonWidget.builder(Text.literal("▲ Scroll Up"), btn -> {
            if (scrollOffset > 0) {
                scrollOffset--;
                rebuildWidgets();
            }
        }).dimensions(left + 8, catY + 4, 115, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("▼ Scroll Down"), btn -> {
            List<ToggleOption> options = getFilteredOptions();
            int maxRows = (panelH - 50) / 26;
            int maxScroll = Math.max(0, options.size() - maxRows);
            if (scrollOffset < maxScroll) {
                scrollOffset++;
                rebuildWidgets();
            }
        }).dimensions(left + 8, catY + 26, 115, 20).build());

        // Search field
        searchField = new TextFieldWidget(this.textRenderer, left + 135, top + 10, panelW - 145, 20, Text.literal("Search..."));
        searchField.setPlaceholder(Text.literal("Search BEF features..."));
        searchField.setText(searchQuery);
        searchField.setChangedListener(s -> {
            if (!s.equals(searchQuery)) {
                searchQuery = s;
                scrollOffset = 0;
                rebuildWidgets();
            }
        });
        addDrawableChild(searchField);

        // S+ message input when in Dungeons tab
        if (activeCategory == Category.DUNGEONS) {
            sPlusMessageField = new TextFieldWidget(this.textRenderer, left + 8, top + panelH - 52, 115, 18, Text.literal("S+ Msg"));
            sPlusMessageField.setMaxLength(100);
            sPlusMessageField.setText(BefConfig.INSTANCE.sPlusMessageText);
            sPlusMessageField.setChangedListener(s -> BefConfig.INSTANCE.sPlusMessageText = s);
            addDrawableChild(sPlusMessageField);
        }

        // Save & Close
        addDrawableChild(ButtonWidget.builder(Text.literal("Save & Close"), btn -> close())
                .dimensions(left + 8, top + panelH - 28, 115, 20).build());

        rebuildOptionButtons(left, top, panelW, panelH);
    }

    private List<ToggleOption> getFilteredOptions() {
        List<ToggleOption> base = switch (activeCategory) {
            case QOL -> qolOptions;
            case DUNGEONS -> dungeonOptions;
            case F7_M7 -> f7m7Options;
            case EXPERIMENTATION -> experimentOptions;
            case SLAYERS -> slayerOptions;
        };
        String query = searchQuery != null ? searchQuery.trim().toLowerCase() : "";
        if (query.isEmpty()) return base;
        List<ToggleOption> filtered = new ArrayList<>();
        for (ToggleOption opt : base) {
            if (opt.name().toLowerCase().contains(query) || opt.description().toLowerCase().contains(query)) {
                filtered.add(opt);
            }
        }
        return filtered;
    }

    private void rebuildOptionButtons(int left, int top, int panelW, int panelH) {
        List<ToggleOption> options = getFilteredOptions();
        int listY = top + 40;
        int rowH = 26;
        int maxRows = (panelH - 50) / rowH;

        int end = Math.min(options.size(), scrollOffset + maxRows);
        for (int i = scrollOffset; i < end; i++) {
            ToggleOption opt = options.get(i);
            int y = listY + (i - scrollOffset) * rowH;
            boolean enabled = opt.getter().get();
            Text label = Text.literal(enabled ? "§aON" : "§cOFF");
            addDrawableChild(ButtonWidget.builder(label, btn -> {
                boolean next = !opt.getter().get();
                opt.setter().accept(next);
                btn.setMessage(Text.literal(next ? "§aON" : "§cOFF"));
            }).dimensions(left + panelW - 58, y, 48, 20).build());
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        List<ToggleOption> options = getFilteredOptions();
        int panelH = Math.min(340, this.height - 24);
        int maxRows = (panelH - 50) / 26;
        int maxScroll = Math.max(0, options.size() - maxRows);
        if (verticalAmount < 0 && scrollOffset < maxScroll) {
            scrollOffset++;
            rebuildWidgets();
            return true;
        } else if (verticalAmount > 0 && scrollOffset > 0) {
            scrollOffset--;
            rebuildWidgets();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);

        int panelW = Math.min(540, this.width - 24);
        int panelH = Math.min(340, this.height - 24);
        int left = (this.width - panelW) / 2;
        int top = (this.height - panelH) / 2;

        // Main dark panel
        context.fill(left, top, left + panelW, top + panelH, 0xE614171F);
        context.drawBorder(left, top, panelW, panelH, 0xFF3A4154);
        context.fill(left, top, left + 128, top + panelH, 0xFF0E1016);

        context.drawTextWithShadow(this.textRenderer, "§b§lBEF §71.21.1", left + 12, top + 14, 0xFFFFFFFF);

        // Render option labels
        List<ToggleOption> options = getFilteredOptions();
        int listX = left + 136;
        int listY = top + 42;
        int rowH = 26;
        int maxRows = (panelH - 50) / rowH;
        int end = Math.min(options.size(), scrollOffset + maxRows);

        for (int i = scrollOffset; i < end; i++) {
            ToggleOption opt = options.get(i);
            int y = listY + (i - scrollOffset) * rowH;
            context.drawTextWithShadow(this.textRenderer, opt.name(), listX, y, 0xFFFFFFFF);
            context.drawTextWithShadow(this.textRenderer, "§7" + opt.description(), listX, y + 10, 0xFF9AA3B2);
        }

        if (activeCategory == Category.DUNGEONS) {
            context.drawTextWithShadow(this.textRenderer, "§7S+ Msg:", left + 8, top + panelH - 63, 0xFFCCCCCC);
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        BefConfig.save();
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}
