# BilliEnoughFakepixel (BEF) — Fabric 1.21.1

**BilliEnoughFakepixel (`BEF`)** is a Fabric 1.21.1 mod for **Fakepixel Skyblock**, specially optimized for **Poco X6 Pro**, low-end Android devices, **Zalith Launcher**, **MobileGlues**, and **GL4ES** renderers.

## Mobile & Renderer Optimizations
- **MobileGlues & GL4ES Safe Mode** (Enabled by default in `/bef`): Uses standard batched `VertexConsumerProvider` layers (`RenderLayer.getLines()`, `RenderLayer.getDebugFilledBox()`, and `TextLayerType.SEE_THROUGH`) without mid-buffer `glDisable(GL_DEPTH_TEST)` state changes that cause driver stalls or depth-buffer glitches on **MobileGlues** and **GL4ES**.
- **Low-End Mobile Fast Mode**: Switches 3D filled boxes to pure wireframe, tightens scan radii, and throttles background block/entity checks for maximum FPS on budget phones.
- **Zero Per-Frame Entity/Scoreboard Scans**: All Dungeon, F7/M7, Slayer, and Scoreboard checks are cached on throttled client ticks rather than inside the render loop.

## Commands & Controls
- **`/bef`** (or **`/billienoughfakepixel`** / **`Right Shift`**): Opens the touch-friendly **BEF Config GUI** (includes `▲ Scroll Up` and `▼ Scroll Down` buttons for mobile touchscreens).
- **Auto-Build on Mobile via GitHub Actions**: Upload this folder (including `.github/workflows/build.yml`) to a GitHub repository and download the compiled `.jar` from the **Actions** tab.
